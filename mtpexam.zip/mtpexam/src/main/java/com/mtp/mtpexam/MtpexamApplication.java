package com.mtp.mtpexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtpexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtpexamApplication.class, args);
	}

}
